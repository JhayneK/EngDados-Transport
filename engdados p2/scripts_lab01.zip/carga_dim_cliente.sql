--v3a (COM CTE) prevendo atualizacao SCD1
WITH cliente_relacional AS (
	SELECT cd_cliente,
		   nome,
		   cpf,
		   sexo,
		   dt_nascimento
	  FROM relacional.cliente
)
MERGE INTO
	dimensional.dim_cliente AS d
USING
	cliente_relacional AS r

ON r.cd_cliente = d.cd_cliente   

WHEN NOT MATCHED BY TARGET  THEN
	INSERT (cd_cliente, nome, cpf, sexo, dt_nascimento)
	VALUES (r.cd_cliente, r.nome, r.cpf, r.sexo, r.dt_nascimento)

WHEN MATCHED AND (r.cd_cliente <> d.cd_cliente OR r.nome <> d.nome OR r.cpf <> d.cpf OR r.sexo <> d.sexo OR r.dt_nascimento <> d.dt_nascimento) THEN
	UPDATE SET cd_cliente    = r.cd_cliente,
	           nome          = r.nome,
			   cpf           = r.cpf,
			   sexo          = r.sexo,
			   dt_nascimento = r.dt_nascimento
;

select * from relacional.cliente where cd_cliente > 20010
select * from dimensional.dim_cliente where cd_cliente > 20010





