
--CARGA FULL
with apolice_cliente as (
	select a.cd_cliente, placa from relacional.apolice a inner join relacional.cliente c on a.cd_cliente = c.cd_cliente
)
insert into dimensional.fato_sinistro
select sk_tempo,
       sk_localidade,
	   sk_carro,
	   sk_cliente,
	   count(1) as qtde_sinistro
from relacional.sinistro r
       inner join dimensional.dim_carro dcar
	     on r.placa = dcar.placa
	   inner join apolice_cliente ac
	     on ac.placa = r.placa
	   inner join dimensional.dim_cliente dcli
	     on ac.cd_cliente = dcli.cd_cliente
	   inner join dimensional.dim_localidade dloc
	     on r.local_sinistro = dloc.cd_municipio
	   inner join dimensional.dim_tempo dtem
	     on r.dt_sinistro = dtem.data
group by sk_tempo,
       sk_localidade,
	   sk_carro,
	   sk_cliente
;

--CARGA POR ANO
with apolice_cliente as (
	select a.cd_cliente, placa from relacional.apolice a inner join relacional.cliente c on a.cd_cliente = c.cd_cliente
)
select sk_tempo,
       sk_localidade,
	   sk_carro,
	   sk_cliente,
	   count(1) as qtde_sinistro
from relacional.sinistro r
       inner join dimensional.dim_carro dcar
	     on r.placa = dcar.placa
	   inner join apolice_cliente ac
	     on ac.placa = r.placa
	   inner join dimensional.dim_cliente dcli
	     on ac.cd_cliente = dcli.cd_cliente
	   inner join dimensional.dim_localidade dloc
	     on r.local_sinistro = dloc.cd_municipio
	   inner join dimensional.dim_tempo dtem
	     on r.dt_sinistro = dtem.data
WHERE YEAR(dt_sinistro) = 2024
group by sk_tempo,
       sk_localidade,
	   sk_carro,
	   sk_cliente
;

