--v3a (COM CTE) prevendo atualizacao SCD1
WITH carros_relacional AS (
	SELECT placa,
		   nm_marca,
		   nm_modelo,
		   cor,
		   ano,
		   chassi 
	  FROM relacional.carro c
		   INNER JOIN relacional.modelo mo
		     ON c.cd_modelo = mo.cd_modelo
		   INNER JOIN relacional.marca ma
		     ON mo.cd_marca = ma.cd_marca
)
MERGE INTO
	dimensional.dim_carro AS c
USING
	carros_relacional AS cc
ON c.placa = cc.placa   
WHEN NOT MATCHED BY TARGET  THEN
	INSERT (placa, marca, modelo, cor, ano, chassi)
	VALUES (cc.placa, cc.nm_marca, cc.nm_modelo, cc.cor, cc.ano, cc.chassi)
WHEN MATCHED AND (c.marca <> cc.nm_marca OR c.modelo <> cc.nm_modelo OR c.cor <> cc.cor OR c.ano <> cc.ano OR c.chassi <> cc.chassi) THEN
	UPDATE SET placa  = cc.placa,
	           marca  = cc.nm_marca,
			   modelo = cc.nm_modelo,
			   cor    = cc.cor,
			   ano    = cc.ano,
			   chassi = cc.chassi
;


/*
--v6 (com cte) prevendo atualizacao SCD2
--Criando estrutura para aceitar o SCD2
ALTER TABLE dimensional.dim_carro ADD start_edit datetime, end_edit datetime, status bit
go
*/

--WITH carros_desnormalizado AS (
--	SELECT placa,
--		   nm_marca,
--		   nm_modelo,
--		   cor,
--		   ano,
--		   chassi 
--	  FROM relacional.carro c
--		   INNER JOIN relacional.modelo mo
--		     ON c.cd_modelo = mo.cd_modelo
--		   INNER JOIN relacional.marca ma
--		     ON mo.cd_marca = ma.cd_marca
--),
--carros_relacional AS (
--	SELECT placa AS join_key, * FROM carros_desnormalizado AS r
--	UNION ALL
--	SELECT NULL, r.* FROM carros_desnormalizado AS r INNER JOIN dimensional.dim_carro d ON r.placa = d.placa
--	WHERE (r.placa<> d.placa OR r.nm_marca <> d.marca OR r.nm_modelo <> d.modelo OR r.cor <> d.cor OR r.ano <> d.ano OR r.chassi <> d.chassi)
--	AND d.end_edit is null
--)
--MERGE INTO
--	dimensional.dim_carro AS d
--USING
--	carros_relacional AS r

--ON r.placa = d.placa   

--WHEN NOT MATCHED BY TARGET  THEN
--	INSERT (placa, marca, modelo, cor, ano, chassi, start_edit, end_edit, status)
--	VALUES (r.placa, r.nm_marca, r.nm_modelo, r.cor, r.ano, r.chassi, getdate(), null, 1)

--WHEN MATCHED AND (r.placa <> d.placa OR r.nm_marca <> d.marca OR r.nm_modelo <> d.modelo OR r.cor <> d.cor OR r.ano <> d.ano OR r.chassi <> d.chassi) THEN
--	UPDATE SET d.end_edit = getdate(), d.status = 0;




