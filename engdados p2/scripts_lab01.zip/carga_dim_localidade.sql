--v3a (COM CTE) prevendo atualizacao SCD1
WITH localidade_relacional AS (
	SELECT cd_municipio,
		   nm_municipio,
		   nm_estado,
		   nm_regiao
	  FROM relacional.municipio m
		   INNER JOIN relacional.estado e
		     ON m.cd_estado = e.cd_estado
		   INNER JOIN relacional.regiao r
		     ON e.cd_regiao = r.cd_regiao
)
MERGE INTO
	dimensional.dim_localidade AS d
USING
	localidade_relacional AS r

ON r.cd_municipio = d.cd_municipio

WHEN NOT MATCHED BY TARGET  THEN
	INSERT (cd_municipio, nm_municipio, nm_estado, nm_regiao)
	VALUES (r.cd_municipio, r.nm_municipio, r.nm_estado, r.nm_regiao)
WHEN MATCHED AND (r.cd_municipio <> d.cd_municipio OR r.nm_municipio <> d.nm_municipio OR r.nm_estado <> d.nm_estado OR r.nm_regiao <> d.nm_regiao) THEN
	UPDATE SET cd_municipio = r.cd_municipio,
		       nm_municipio = r.nm_municipio,
			   nm_estado    = r.nm_estado,
		       nm_regiao    = r.nm_regiao
;


SELECT cd_municipio,
		nm_municipio,
		nm_estado,
		nm_regiao
	FROM relacional.municipio m
		INNER JOIN relacional.estado e
		    ON m.cd_estado = e.cd_estado
		INNER JOIN relacional.regiao r
		    ON e.cd_regiao = r.cd_regiao
	where cd_municipio = 1100098

select * from dimensional.dim_localidade WHERE cd_municipio = 1100098
