
SET LANGUAGE PORTUGUESE;

WITH Calendario AS (
    SELECT 
        DATEADD(DAY, number, '2023-01-01') AS Data
    FROM 
        master..spt_values
    WHERE 
        type = 'P' 
        AND number BETWEEN 0 AND DATEDIFF(DAY, '2023-01-01', '2026-12-31') -- Altere para o intervalo desejado
)
--insert into dimensional.dim_tempo
SELECT CAST (Data as date) as Data,
    YEAR(Data) AS Ano,
    MONTH(Data) AS Mes,
    UPPER(DATENAME(MONTH, Data)) AS NomeMes,
    DAY(Data) AS Dia,
    UPPER(DATENAME(WEEKDAY, Data)) AS NomeDiaSemana,
    DATEPART(WEEKDAY, Data) AS NumeroDiaSemana
FROM Calendario

